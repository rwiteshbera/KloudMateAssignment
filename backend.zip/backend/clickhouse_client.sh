docker exec -it clickhouse clickhouse-client --user default
